# Gluttony stack check - max level 2
execute store result score #current rituals.soul_temp run data get storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony

execute unless data storage rituals:temp item.components."minecraft:custom_data".soul_debuffs[{id:"gluttony"}] run data modify storage rituals:temp item.components."minecraft:custom_data".soul_debuffs append from storage rituals:temp new_debuff
execute unless data storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony run data modify storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony set value 1
execute unless data storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony run tellraw @a[distance=..16] [{"text":"  👅 ","color":"dark_purple"},{"text":"Soul Hunger I","color":"light_purple"},{"text":" afflicted!","color":"red"}]
execute unless data storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony run return 1

execute if score #current rituals.soul_temp matches 1 run data modify storage rituals:temp item.components."minecraft:custom_data".soul_debuff_levels.gluttony set value 2
execute if score #current rituals.soul_temp matches 1 run tellraw @a[distance=..16] [{"text":"  👅 ","color":"dark_purple"},{"text":"Soul Hunger","color":"light_purple"},{"text":" → II (MAX)!","color":"red","bold":true}]

execute if score #current rituals.soul_temp matches 2.. run tellraw @a[distance=..16] [{"text":"  ⚠ ","color":"yellow"},{"text":"Soul Hunger already at max!","color":"gray"}]

